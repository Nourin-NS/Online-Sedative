package com.ust;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.ClassOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.ust.model.Product;
import com.ust.repo.ProductRepository;

@SpringBootTest
@TestMethodOrder(org.junit.jupiter.api.MethodOrderer.OrderAnnotation.class)
class OnlineSedativeApplicationTests {

	@Autowired
	ProductRepository pRepo;
	
	@Test
	
	void contextLoads() {
	}
	
	
	
	@Test
	@Order(1)
	public void testCreate() {
		Product p=new Product();
		//p.setPid(11);
		p.setPname("Dolo");

		p.setPrice(50.0);;
		p.setDisc(4);
		p.setCat("tablet");
		p.setVen("Micro Labs");
		
		pRepo.save(p);
		assertNotNull(pRepo.findById(p.getPid()).get());
		
	}
	
	
	  @Test
	  
	  @Order(2) public void testReadAll() { List<Product> list=pRepo.findAll();
	  assertThat(list).size().isGreaterThan(0);
	  
	  }
	  
		
		  @Test
		  
		  @Order(3) public void testReadOne() { Product
		  product=pRepo.findById(101).get(); assertEquals("Dolo", product.getPname());
		  
		  }
		  
			
			  @Test
			  
			  @Order(4) public void testUpdate() {
			  
			  Product p =pRepo.findById(100).get(); p.setPname("Paracetamol"); pRepo.save(p);
			  assertNotEquals("Dolo", pRepo.findById(101).get().getPname());
			  
			  }
			  
			  @Test
			  
			  @Order(5) public void testDelete() { pRepo.deleteById(102);
			  assertThat(pRepo.existsById(102)).isFalse();
			  
			  }
			 
		 

}