package com.ust.repo;
import org.springframework.data.jpa.repository.JpaRepository;

import com.ust.model.Category;

public interface CategoryRepository extends JpaRepository<Category,Integer>{

}
