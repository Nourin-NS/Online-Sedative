package com.ust;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineSedativeApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineSedativeApplication.class, args);
	}

}
