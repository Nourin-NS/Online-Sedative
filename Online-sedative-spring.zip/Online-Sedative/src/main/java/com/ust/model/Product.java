package com.ust.model;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@Data
@NoArgsConstructor 
@RequiredArgsConstructor 
@AllArgsConstructor
@Entity
public class Product {

	
	
	//@OneToOne(mappedBy = "product", cascade = CascadeType.ALL,
		    //fetch = FetchType.LAZY, optional = false)
	
	@Id 
 	@GeneratedValue 
	private Integer pid; 
 	
  		
 	@NonNull 
 	private String pname;  			
 	@NonNull 
 	private Double price;  			
 	@NonNull 
 	private Integer disc; 
 	@NonNull
 	private String cat;
 	@NonNull
 	private String ven;
 	
	
}

 
 	
 
