package com.ust.model;


	import javax.persistence.Entity;
	import javax.persistence.GeneratedValue;
	import javax.persistence.Id;
	import lombok.AllArgsConstructor;
	import lombok.Data;
	import lombok.NoArgsConstructor;
	import lombok.NonNull;
	import lombok.RequiredArgsConstructor;

	@Data
	@NoArgsConstructor 
	@RequiredArgsConstructor 
	@AllArgsConstructor
	@Entity

	public class Customer {
		@Id 
	 	@GeneratedValue  			
	 	private Integer cid;  		
	 	@NonNull 
	 	private String cname;  			
	 	@NonNull 
	 	private String cuser;
	 	@NonNull
	 	private String cpwd;
	 	
		
	


}
