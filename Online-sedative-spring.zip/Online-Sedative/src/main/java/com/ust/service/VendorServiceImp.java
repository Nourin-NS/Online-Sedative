package com.ust.service;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.model.Vendor;

import com.ust.repo.VendorRepository;

@Service
public class VendorServiceImp{

	@Autowired 
 	private VendorRepository repo; //HAS-A 
 	 
 	
 	public Integer saveVendor(Vendor s) { 
 	 	return repo.save(s).getVid(); 
 	} 

 	public List<Vendor> getAllVendors() {  	 		return repo.findAll(); 
 	} 
 	  

 	public void deleteVendor(Integer id) {  	 				repo.deleteById(id); 
 	} 

 	public boolean isExist(Integer id) {  	return repo.existsById(id);
}
 
 	public Optional<Vendor> getOneVendor(Integer id) { 
 	 	return repo.findById(id); 
 	}
}