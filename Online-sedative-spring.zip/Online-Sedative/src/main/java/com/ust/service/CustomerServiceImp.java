package com.ust.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.model.Customer;

import com.ust.repo.CustomerRepository;

@Service
public class CustomerServiceImp {

	@Autowired 
 	private CustomerRepository repo; //HAS-A 
 	 
 	
 	public Integer saveCustomer(Customer s) { 
 	 	return repo.save(s).getCid(); 
 	} 
 	
 	public List<Customer> getAllProduct() {  	 		
 		return repo.findAll(); 
 	} 
 	  
 	
 	public void deleteAllCustomer() {  	 				
 		repo.deleteAll(); 
 	} 
 	
 
 	public void deleteCustomer(Integer id) {  	 				repo.deleteById(id); 
 	} 
 	 
 	
 	public boolean isExist(Integer id) {  	return repo.existsById(id);
}
 	
 	public Optional<Customer> getOneCustomer(Integer id) { 
 	 	return repo.findById(id); 
 	}
}