package com.ust.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.model.Product;
import com.ust.repo.ProductRepository;

@Service
public class ProductServiceImp implements IProductService {

	@Autowired 
 	private ProductRepository repo; //HAS-A 
 	 
 	@Override 
 	public Integer saveProduct(Product s) { 
 	 	return repo.save(s).getPid(); 
 	} 
 	@Override 
 	public List<Product> getAllProduct() {  	 		return repo.findAll(); 
 	} 
 	  
 	 
 	@Override 
 	public void deleteProduct(Integer id) {  	 				repo.deleteById(id); 
 	} 
 	 
 	@Override 
 	public boolean isExist(Integer id) {  	return repo.existsById(id);
}
 	@Override 
 	public Optional<Product> getOneProduct(Integer id) { 
 	 	return repo.findById(id); 
 	}
}