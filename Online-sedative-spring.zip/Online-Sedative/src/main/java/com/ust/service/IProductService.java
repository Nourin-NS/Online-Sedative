package com.ust.service;

import java.util.List;
import java.util.Optional;

import com.ust.model.Product;

public interface IProductService {
	public Integer saveProduct(Product s);  	
	public List<Product> getAllProduct();    
	public boolean isExist(Integer id);  	
	public void deleteProduct(Integer id); 
	public Optional<Product> getOneProduct(Integer id);
}
