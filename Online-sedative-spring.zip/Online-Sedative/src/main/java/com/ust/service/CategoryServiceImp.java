

package com.ust.service;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.model.Category;
import com.ust.repo.CategoryRepository;


@Service
public class CategoryServiceImp {

	@Autowired 
 	private CategoryRepository repo; //HAS-A 
 	 
 	
 	public Integer saveCategory(Category s) { 
 	 	return repo.save(s).getCatid(); 
 	} 

 	public List<Category> getAllCategory() {  	 		return repo.findAll(); 
 	} 
 	  

 	public void deleteCategory(Integer id) {  	 				repo.deleteById(id); 
 	} 

 	public boolean isExist(Integer id) {  	return repo.existsById(id);
}
 
 	public Optional<Category> getOneCategory(Integer id) { 
 	 	return repo.findById(id); 
 	}
}