
package com.ust.service;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.ust.model.Discount;

import com.ust.repo.DiscountRepository;


@Service
public class DiscountServiceImp {

	@Autowired 
 	private DiscountRepository repo; //HAS-A 
 	 
 	
 	public Integer saveDiscount(Discount s) { 
 	 	return repo.save(s).getDid(); 
 	} 

 	public List<Discount> getAllDiscount() {  	 		return repo.findAll(); 
 	} 
 	  

 	public void deleteDiscount(Integer id) {  	 				repo.deleteById(id); 
 	} 

 	public boolean isExist(Integer id) {  	return repo.existsById(id);
}
 
 	public Optional<Discount> getOneDiscount(Integer id) { 
 	 	return repo.findById(id); 
 	}
}