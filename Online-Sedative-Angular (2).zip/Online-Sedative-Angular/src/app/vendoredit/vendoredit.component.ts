import { Component, OnInit } from '@angular/core';
import { ProductserviceService } from '../productservice.service'; 

import { ActivatedRoute, Router } from '@angular/router'; 
import { Vendor } from '../vendor';

@Component({
  selector: 'app-vendoredit',
  templateUrl: './vendoredit.component.html',
  styleUrls: ['./vendoredit.component.css']
})
export class VendoreditComponent {

  vendor:Vendor= new Vendor() ;   
  id : number=0; 
 
  constructor(private service:ProductserviceService,private activeRouter:ActivatedRoute, private router:Router) { } 
 
  ngOnInit(): void {     this.vendor =new Vendor(); 
    this.id=this.activeRouter.snapshot.params['id'];     this.service.getOneVendor(this.id).subscribe(       data=>{ 
        this.vendor=data; 
      } 
    );   } 	
updateVendor(){ 
  
    this.service.updateVendor(this.vendor).subscribe(data=>{ 
       console.log(data), this.router.navigate(['\adminlogin/vall']);
    });
     
     
  } 
}
