import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Discount } from '../discount';
import { Message } from '../message';

import { ProductserviceService } from '../productservice.service';
import * as pdfMake from "pdfmake/build/pdfmake";
import * as pdfFonts from "pdfmake/build/vfs_fonts";
declare var require: any;
const htmlToPdfmake = require("html-to-pdfmake");
(pdfMake as any).vfs = pdfFonts.pdfMake.vfs;

@Component({
  selector: 'app-discountdetails',
  templateUrl: './discountdetails.component.html',
  styleUrls: ['./discountdetails.component.css']
})
export class DiscountdetailsComponent implements OnInit {

  disc : Discount[]=[]; 
  message  : Message = new Message(); 

  @ViewChild('pdfTable')
  pdfTable!: ElementRef;
  
  public downloadAsPDF() {
    const pdfTable = this.pdfTable.nativeElement;
    var html = htmlToPdfmake(pdfTable.innerHTML);
    const documentDefinition = { content: html };
    pdfMake.createPdf(documentDefinition).download('discount details.pdf'); 
     
  }

  constructor(private service:ProductserviceService, private router:Router) {
 } 
 
  ngOnInit(): void {     this.getAllDiscount(); 
  }  



  getAllDiscount(){ 
    this.service.getAllDiscount().subscribe(data=>{this.disc=data}
,       error=>{this.disc=[] 
      });   } 

      
}
