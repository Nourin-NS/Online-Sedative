export class Vendor {

    vid:number=0;
    vname:string="";

    
}
