import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Category } from '../category';
import { Message } from '../message';
import { Product } from '../product';
import { ProductserviceService } from '../productservice.service';
import { Vendor } from '../vendor';

@Component({
  selector: 'app-categoryall',
  templateUrl: './categoryall.component.html',
  styleUrls: ['./categoryall.component.css']
})
export class CategoryallComponent implements OnInit {

 
  category : Category[]=[]; 
  message  : Message = new Message(); 
 
  constructor(private service:ProductserviceService, private router:Router) {
 } 
 
  ngOnInit(): void {     this.getAllCategory(); 
  }  

  deleteCategory(id:number){ 
    this.service.deleteOneCategory(id).subscribe( 
      data=>{         this.message=data,         this.getAllCategory(); 
      }, 
      error=>{console.log(error)} 
      ); 
       } 

  getAllCategory(){ 
    this.service.getAllCategory().subscribe(data=>{this.category=data}
,       error=>{this.category=[] 
      });   } 

      editCategory(pid:number){ 
        this.router.navigate(['catedit',pid]); 
      } 
    
}
