import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminComponent } from './admin/admin.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { AppComponent } from './app.component';
import { CategoryallComponent } from './categoryall/categoryall.component';
import { CategorycreateComponent } from './categorycreate/categorycreate.component';
import { CategorydisplayComponent } from './categorydisplay/categorydisplay.component';
import { CategoryeditComponent } from './categoryedit/categoryedit.component';
import { CreditComponent } from './credit/credit.component';
import { CustomeraddComponent } from './customeradd/customeradd.component';
import { CustomerallComponent } from './customerall/customerall.component';
import { CustomerdeleteComponent } from './customerdelete/customerdelete.component';
import { DiscountallComponent } from './discountall/discountall.component';
import { DiscountcreateComponent } from './discountcreate/discountcreate.component';
import { DiscountdetailsComponent } from './discountdetails/discountdetails.component';
import { DiscounteditComponent } from './discountedit/discountedit.component';
import { DisplayorderComponent } from './displayorder/displayorder.component';
import { HomeComponent } from './home/home.component';
import { OrderconfirmComponent } from './orderconfirm/orderconfirm.component';
import { OrderproductComponent } from './orderproduct/orderproduct.component';
import { ProductallComponent } from './productall/productall.component';
import { ProductcreateComponent } from './productcreate/productcreate.component';
import { ProductdetailsComponent } from './productdetails/productdetails.component';
import { ProducteditComponent } from './productedit/productedit.component';
import { ReportsComponent } from './reports/reports.component';
//import { SingupComponent } from './singup/singup.component';
import { UserComponent } from './user/user.component';
import { VendorallComponent } from './vendorall/vendorall.component';
import { VendorcreateComponent } from './vendorcreate/vendorcreate.component';
import { VendordetailsComponent } from './vendordetails/vendordetails.component';
import { VendoreditComponent } from './vendoredit/vendoredit.component';
//import { VendorcreateComponent } from './vendorcreate/vendorcreate.component';

const routes: Routes = [
 {path:'home',component:HomeComponent} ,

 {path:'home/user',component:UserComponent},
 {path:'home/admin',component:AdminComponent},
  {path:'user',component:UserComponent}, 
  {path:'admin',component:AdminComponent}, 
  //{path:'user/signup',component:SingupComponent},
  {path:'adminlogin/pdtall',component:ProductallComponent},
  {path:'adminlogin/pdtadd',component:ProductcreateComponent},
  {path:'pdtedit/:id',component:ProducteditComponent},
  {path:'cusall',component:CustomerallComponent},
  {path:'user/cadd',component:CustomeraddComponent},
  {path:'adminlogin/cdelete',component:CustomerdeleteComponent},
  {path:'adminlogin',component:AdminloginComponent},
  {path:'credit',component:CreditComponent},
  {path:'opdt',component:OrderproductComponent},
  {path:'copdt/:id',component:OrderconfirmComponent},
  {path:'dorder',component:DisplayorderComponent},
  //{path:'vadd',component:VendorcreateComponent}
  {path:'adminlogin/vadd',component:VendorcreateComponent},
  {path:'adminlogin/vall',component:VendorallComponent},
  {path:'vedit/:id',component:VendoreditComponent},
  {path:'adminlogin/report',component:ReportsComponent},
  {path:'vdall',component:VendordetailsComponent},
  {path:'pall',component:ProductdetailsComponent},
  {path:'adminlogin/catall',component:CategoryallComponent},
  {path:'adminlogin/catadd',component:CategorycreateComponent},
  {path:'catedit/:id',component:CategoryeditComponent},
  {path:'catdisplay',component:CategorydisplayComponent},

  {path:'adminlogin/dall',component:DiscountallComponent},
  {path:'adminlogin/dadd',component:DiscountcreateComponent},
  {path:'dedit/:id',component:DiscounteditComponent},
  {path:'ddisplay',component:DiscountdetailsComponent}


]; 

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
