import { Component, OnInit } from '@angular/core';


import { Product } from '../product';


@Component({
  selector: 'app-displayorder',
  templateUrl: './displayorder.component.html',
  styleUrls: ['./displayorder.component.css']
})
export class DisplayorderComponent  {

  
  product :Product= new Product() ;   
  id : number=0; 
 
  constructor() { } 
 
  

}
