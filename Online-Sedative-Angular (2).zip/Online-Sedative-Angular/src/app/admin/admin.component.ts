import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';



@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent {
  username:string="";
  upwd:string="";
  msg:string="";
  msg1:string="";
  
 
//creating service class object in component
  constructor(private route:Router)
  {
  }


 


 getValidation(tx1:any)
 {
      //calling a service class method

   
        if(this.username=="admin" && this.upwd=="admin"){
          this.msg="Successfully Login";
          this.route.navigateByUrl('/adminlogin')
         
        } 
        else
        {
          this.msg="Username or Password Incorrect";
          tx1.focus;
          this.msg1=this.msg;
        }
    }
}
