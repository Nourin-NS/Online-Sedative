import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { Product } from '../product'; 
import { ProductserviceService } from '../productservice.service';
@Component({
  selector: 'app-orderconfirm',
  templateUrl: './orderconfirm.component.html',
  styleUrls: ['./orderconfirm.component.css']
})
export class OrderconfirmComponent implements OnInit {

  
  product :Product= new Product() ;   
  id : number=0; 
 
  constructor(private service:ProductserviceService,private activeRouter:ActivatedRoute, private router:Router) { } 
 
  ngOnInit(): void {     this.product =new Product(); 
    this.id=this.activeRouter.snapshot.params['id'];     this.service.getOneStudent(this.id).subscribe(       data=>{ 
        this.product=data; 
      } 
    );   } 	
confirmOrder(){ 
  
  this.router.navigateByUrl('\credit');
    
     
     
  } 
}
