import { Component, OnInit } from '@angular/core';
import { ProductserviceService } from '../productservice.service'; 
import { Router } from '@angular/router'; 
import {Customer } from '../customer'; 
import { Message } from '../message';  
@Component({
  selector: 'app-customeradd',
  templateUrl: './customeradd.component.html',
  styleUrls: ['./customeradd.component.css']
})
export class CustomeraddComponent implements OnInit {

  customer : Customer = new Customer();   
  message : Message = new Message(); 
  pwd:string="";
  msg:string=""
  user:Customer[]=[];
  user1:any
  flag:number=0;
  constructor(private service:ProductserviceService,private router:Router) { }  
  ngOnInit(): void { 
   } 
   createCustomer(){ 
    

             
                //console.log('flag=',this.flag)
               
                if(this.pwd==this.customer.cpwd){
                  this.service.createCustomer(this.customer).subscribe(data=>{  this.message=data; 
                  }); 
                  this.customer=new Customer(); 
                  alert(this.msg="Successfully Registered!...")
                  this.router.navigateByUrl("/user")
                }else{
                  this.msg="password does not match"
                } 
              }
              
}


