import { Component, OnInit } from '@angular/core';
import { ProductserviceService } from '../productservice.service'; 
import { Router } from '@angular/router'; 
 
import { Message } from '../message'; 
import { Vendor } from '../vendor';
@Component({
  selector: 'app-vendorcreate',
  templateUrl: './vendorcreate.component.html',
  styleUrls: ['./vendorcreate.component.css']
})
export class VendorcreateComponent  {

  vendor : Vendor = new Vendor();   
  message : Message = new Message(); 
 
  constructor(private service:ProductserviceService,private router:Router) { }  
 

  createVendor(){ 
    this.service.createvendor(this.vendor).subscribe(data=>{       this.message=data; 
    }); 
    this.vendor=new Vendor(); 
  } 
}
