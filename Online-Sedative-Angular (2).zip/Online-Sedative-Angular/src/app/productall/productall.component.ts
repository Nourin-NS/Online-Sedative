import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Message } from '../message';
import { Product } from '../product';
import { ProductserviceService } from '../productservice.service';

@Component({
  selector: 'app-productall',
  templateUrl: './productall.component.html',
  styleUrls: ['./productall.component.css']
})
export class ProductallComponent implements OnInit {

  product : Product[]=[]; 
  message  : Message = new Message(); 
 
  constructor(private service:ProductserviceService, private router:Router) {
 } 
 
  ngOnInit(): void {     this.getAllProducts(); 
  }  

  deleteProduct(id:number){ 
    this.service.deleteOneStudent(id).subscribe( 
      data=>{         this.message=data,         this.getAllProducts(); 
      }, 
      error=>{console.log(error)} 
      ); 
       } 

  getAllProducts(){ 
    this.service.getAllStudents().subscribe(data=>{this.product=data}
,       error=>{this.product=[] 
      });   } 

      editProduct(pid:number){ 
        this.router.navigate(['pdtedit',pid]); 
      } 
    

}
