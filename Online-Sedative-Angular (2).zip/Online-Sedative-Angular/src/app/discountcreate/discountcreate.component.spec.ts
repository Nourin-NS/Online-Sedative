import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DiscountcreateComponent } from './discountcreate.component';

describe('DiscountcreateComponent', () => {
  let component: DiscountcreateComponent;
  let fixture: ComponentFixture<DiscountcreateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DiscountcreateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DiscountcreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
