import { Component, OnInit } from '@angular/core';
import { ProductserviceService } from '../productservice.service'; 
import { Router } from '@angular/router'; 
 
import { Message } from '../message'; 
import { Discount } from '../discount';

@Component({
  selector: 'app-discountcreate',
  templateUrl: './discountcreate.component.html',
  styleUrls: ['./discountcreate.component.css']
})
export class DiscountcreateComponent {

  disc : Discount = new Discount();   
  message : Message = new Message(); 
 
  constructor(private service:ProductserviceService,private router:Router) { }  
 

  createDiscount(){ 
    this.service.createDiscount(this.disc).subscribe(data=>{       this.message=data; 
    }); 
    this.disc=new Discount(); 
  } 
}