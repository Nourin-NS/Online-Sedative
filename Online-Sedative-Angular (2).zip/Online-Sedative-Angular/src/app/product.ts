export class Product {

    pid : number=0;     
    pname : string="";    
    price : number=0;     
    cat: string="";
    disc:number=0;
    ven:string="";
    
  
}
