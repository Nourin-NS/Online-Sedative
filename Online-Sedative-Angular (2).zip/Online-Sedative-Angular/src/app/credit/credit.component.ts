import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-credit',
  templateUrl: './credit.component.html',
  styleUrls: ['./credit.component.css']
})
export class CreditComponent  {

  cardNumber:string="";
cardName:string="";
expirationDate:string="";
cvv:string="";
msg:string="";

  constructor(private route:Router) { }

addSubmitClick(f:any){

  if(f.valid)
  {
   alert(this.msg= "Payment Successfully Done....!") 
   this.route.navigateByUrl("/dorder")
  }
  else
  {
    this.msg="Payment error....!"
  }

}


}