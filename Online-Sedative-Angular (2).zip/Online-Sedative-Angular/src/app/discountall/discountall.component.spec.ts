import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DiscountallComponent } from './discountall.component';

describe('DiscountallComponent', () => {
  let component: DiscountallComponent;
  let fixture: ComponentFixture<DiscountallComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DiscountallComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DiscountallComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
