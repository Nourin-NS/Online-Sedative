import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Discount } from '../discount';
import { Message } from '../message';
import { Product } from '../product';

import { ProductserviceService } from '../productservice.service';

@Component({
  selector: 'app-discountall',
  templateUrl: './discountall.component.html',
  styleUrls: ['./discountall.component.css']
})
export class DiscountallComponent implements OnInit {

  disc : Discount[]=[]; 
  message  : Message = new Message(); 
  //product:Product[]=[];
  constructor(private service:ProductserviceService, private router:Router) {
  
 } 
 
  ngOnInit(): void {     this.getAllDiscount(); 
  }  

  deleteDiscount(id:number){ 
    this.service.deleteOneDiscount(id).subscribe( 
      data=>{         this.message=data,         this.getAllDiscount(); 
      }, 
      error=>{console.log(error)} 
      ); 
       } 

  getAllDiscount(){ 
    this.service.getAllDiscount().subscribe(data=>{this.disc=data}
,       error=>{this.disc=[] 
      });   
    
    } 

      editDiscount(pid:number){ 
        this.router.navigate(['dedit',pid]); 
      } 
    
}
