import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from '../customer';
import { Message } from '../message';
import { ProductserviceService } from '../productservice.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  ngOnInit(): void {
    
  }
  username:string="";
  upwd:string="";
  msg:string="";
  msg1:string="";
  msg2:string="";
  customer : Customer[]=[]; 
  message  : Message = new Message(); 
  constructor(private service:ProductserviceService,private route:Router)
  {
  }

 getValidation(tx1:any)
 {      this.service.getAllCustomer().subscribe(data=>{this.customer=data}
  ,       error=>{this.customer=[] 
        });
      //calling a service class method
    for(let s of this.customer){
        if(this.username==s.cuser  && this.upwd==s.cpwd){
          this.msg="Successfully Login";
         this.msg2=this.msg;
        this.route.navigateByUrl('/opdt')
        } 
        else
        {
          this.msg="Username or Password Incorrect";
          tx1.focus;
          this.msg1=this.msg;
        }
    }
}
}

 

