export class Discount {

    did:number=0;
    discount:number=0;
}
