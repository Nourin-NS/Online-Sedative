import { Component, OnInit } from '@angular/core';
import { ProductserviceService } from '../productservice.service'; 
import { Router } from '@angular/router'; 
 
import { Message } from '../message'; 

import { Category } from '../category';
@Component({
  selector: 'app-categorycreate',
  templateUrl: './categorycreate.component.html',
  styleUrls: ['./categorycreate.component.css']
})
export class CategorycreateComponent  {

  category : Category = new Category();   
  message : Message = new Message(); 
 
  constructor(private service:ProductserviceService,private router:Router) { }  
 

  createCategory(){ 
    this.service.createCategory(this.category).subscribe(data=>{       this.message=data; 
    }); 
    this.category=new Category(); 
  } 
}
