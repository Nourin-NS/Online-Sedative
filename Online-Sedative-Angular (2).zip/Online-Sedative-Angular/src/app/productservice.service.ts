import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'; 
import { Product } from './product'; 
import { Observable } from 'rxjs'; 
import { Message } from './message'; 
import { Customer } from './customer';
import { Vendor } from './vendor';
import { Category } from './category';
import { Discount } from './discount';


@Injectable({
  providedIn: 'root'
})
export class ProductserviceService {

  private baseUrl : string = 'http://localhost:9898/springboot-crud-rest/rest/product'; 

 
  constructor(private http:HttpClient) { } 
 
  getAllStudents():Observable<Product[]>{ 
    return this.http.get<Product[]>(`${this.baseUrl}/all`); 
  }  
  deleteOneStudent(id:number):Observable<Message>{ 
    return this.http.delete<Message>(`${this.baseUrl}/remove/${id}`); 
  }  
  createStudent(student:Product):Observable<Message>{ 
    return this.http.post<Message>(`${this.baseUrl}/save`,student); 
  }  
  getOneStudent(id:number):Observable<Product>{ 
    return this.http.get<Product>(`${this.baseUrl}/one/${id}`); 
  }  
  updateStudent(student:Product):Observable<Message>{ 
   return this.http.put<Message>(`${this.baseUrl}/update`,student); 
  } 

  
  getAllCustomer():Observable<Customer[]>{ 
    return this.http.get<Customer[]>(`${this.baseUrl}/call`); 
  }  
  deleteAllCustomer():Observable<Message>{ 
    return this.http.delete<Message>(`${this.baseUrl}/delete`); 
  }  
  createCustomer(student:Customer):Observable<Message>{ 
    return this.http.post<Message>(`${this.baseUrl}/csave`,student); 
  }  
  getOneCustomer(id:number):Observable<Product>{ 
    return this.http.get<Product>(`${this.baseUrl}/cone/${id}`); 
  }  
  updateCustomer(student:Customer):Observable<Message>{ 
   return this.http.put<Message>(`${this.baseUrl}/cupdate`,student); 
  } 

  deleteOneCustomer(id:number):Observable<Message>{ 
    return this.http.delete<Message>(`${this.baseUrl}/cremove/${id}`); 
  }  


  getAllVendor():Observable<Vendor[]>{ 
    return this.http.get<Vendor[]>(`${this.baseUrl}/vall`); 
  }  
  deleteOneVendor(id:number):Observable<Message>{ 
    return this.http.delete<Message>(`${this.baseUrl}/vremove/${id}`); 
  }  
  createvendor(student:Vendor):Observable<Message>{ 
    return this.http.post<Message>(`${this.baseUrl}/vsave`,student); 
  }  
  getOneVendor(id:number):Observable<Vendor>{ 
    return this.http.get<Vendor>(`${this.baseUrl}/vone/${id}`); 
  }  
  updateVendor(student:Vendor):Observable<Message>{ 
   return this.http.put<Message>(`${this.baseUrl}/vupdate`,student); 
  } 

  getAllCategory():Observable<Category[]>{ 
    return this.http.get<Category[]>(`${this.baseUrl}/catall`); 
  }  
  deleteOneCategory(id:number):Observable<Message>{ 
    return this.http.delete<Message>(`${this.baseUrl}/catremove/${id}`); 
  }  
  createCategory(student:Category):Observable<Message>{ 
    return this.http.post<Message>(`${this.baseUrl}/catsave`,student); 
  }  
  getOneCategory(id:number):Observable<Category>{ 
    return this.http.get<Category>(`${this.baseUrl}/catone/${id}`); 
  }  
  updateCategory(student:Category):Observable<Message>{ 
   return this.http.put<Message>(`${this.baseUrl}/catupdate`,student); 
  } 

  getAllDiscount():Observable<Discount[]>{ 
    return this.http.get<Discount[]>(`${this.baseUrl}/dall`); 
  }  
  deleteOneDiscount(id:number):Observable<Message>{ 
    return this.http.delete<Message>(`${this.baseUrl}/dremove/${id}`); 
  }  
  createDiscount(student:Discount):Observable<Message>{ 
    return this.http.post<Message>(`${this.baseUrl}/dsave`,student); 
  }  
  getOneDiscount(id:number):Observable<Discount>{ 
    return this.http.get<Discount>(`${this.baseUrl}/done/${id}`); 
  }  
  updateDiscount(student:Discount):Observable<Message>{ 
   return this.http.put<Message>(`${this.baseUrl}/dupdate`,student); 
  } 


}
