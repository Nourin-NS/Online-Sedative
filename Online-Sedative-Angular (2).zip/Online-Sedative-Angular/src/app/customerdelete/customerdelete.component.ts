import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Message } from '../message';
import { Customer } from '../customer';
import { ProductserviceService } from '../productservice.service';
@Component({
  selector: 'app-customerall',
  templateUrl: './customerdelete.component.html',
  styleUrls: ['./customerdelete.component.css']
})
export class CustomerdeleteComponent implements OnInit {

  customer : Customer[]=[]; 
  message  : Message = new Message(); 
 
  constructor(private service:ProductserviceService, private router:Router) {
 } 
 
  ngOnInit(): void {     this.getAllCustomer(); 
  }  

  deleteAllCustomer(){ 
    this.service.deleteAllCustomer().subscribe( 
      data=>{         this.message=data,         this.getAllCustomer(); 
      }, 
      error=>{console.log(error)} 
      ); 
       } 

       deleteCustomer(id:number){ 
        this.service.deleteOneCustomer(id).subscribe(data=>{ this.message=data,this.getAllCustomer(); 
          }, 
          error=>{console.log(error)} 
          ); 
           }
  getAllCustomer(){ 
    this.service.getAllCustomer().subscribe(data=>{this.customer=data}
,       error=>{this.customer=[] 
      });   } 

      editProduct(pid:number){ 
        this.router.navigate(['pdtedit',pid]); 
      } 

}
