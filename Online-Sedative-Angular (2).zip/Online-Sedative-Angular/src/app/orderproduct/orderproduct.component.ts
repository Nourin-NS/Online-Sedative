import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';
import { Message } from '../message';
import { Product } from '../product';
import { ProductserviceService } from '../productservice.service';
@Component({
  selector: 'app-orderproduct',
  templateUrl: './orderproduct.component.html',
  styleUrls: ['./orderproduct.component.css']
})
export class OrderproductComponent implements OnInit {
  product : Product[]=[]; 
  message  : Message = new Message(); 
 
  constructor(private service:ProductserviceService, private router:Router) {
 } 
 
  ngOnInit(): void {     this.getAllProducts(); 
  }  

  getAllProducts(){ 
    this.service.getAllStudents().subscribe(data=>{this.product=data}
,       error=>{this.product=[] 
      });   } 

      OrderProduct(pid:number){ 
        this.router.navigate(['copdt',pid]); 
      } 
    

}
