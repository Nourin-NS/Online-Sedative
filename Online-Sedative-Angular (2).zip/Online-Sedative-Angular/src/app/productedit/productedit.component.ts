import { Component, OnInit } from '@angular/core';
import { ProductserviceService } from '../productservice.service'; 

import { ActivatedRoute, Router } from '@angular/router'; 
import { Product } from '../product'; 
@Component({
  selector: 'app-productedit',
  templateUrl: './productedit.component.html',
  styleUrls: ['./productedit.component.css']
})
export class ProducteditComponent implements OnInit {

  product :Product= new Product() ;   
  id : number=0; 
 
  constructor(private service:ProductserviceService,private activeRouter:ActivatedRoute, private router:Router) { } 
 
  ngOnInit(): void {     this.product =new Product(); 
    this.id=this.activeRouter.snapshot.params['id'];     this.service.getOneStudent(this.id).subscribe(       data=>{ 
        this.product=data; 
      } 
    );   } 	
updateStudent(){ 
  
    this.service.updateStudent(this.product).subscribe(data=>{ 
       console.log(data), this.router.navigate(['\adminlogin/pdtall']);
    });
     
     
  } 
 
} 

