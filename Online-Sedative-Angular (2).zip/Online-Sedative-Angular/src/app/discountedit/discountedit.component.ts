import { Component, OnInit } from '@angular/core';
import { ProductserviceService } from '../productservice.service'; 

import { ActivatedRoute, Router } from '@angular/router'; 
import { Discount } from '../discount';
@Component({
  selector: 'app-discountedit',
  templateUrl: './discountedit.component.html',
  styleUrls: ['./discountedit.component.css']
})
export class DiscounteditComponent implements OnInit {

  disc:Discount= new Discount() ;   
  id : number=0; 
 
  constructor(private service:ProductserviceService,private activeRouter:ActivatedRoute, private router:Router) { } 
 
  ngOnInit(): void {     this.disc =new Discount(); 
    this.id=this.activeRouter.snapshot.params['id'];     this.service.getOneDiscount(this.id).subscribe(       data=>{ 
        this.disc=data; 
      } 
    );   } 	
updateDiscount(){ 
  
    this.service.updateDiscount(this.disc).subscribe(data=>{ 
       console.log(data), this.router.navigate(['\adminlogin/dall']);
    });
     
     
  } 
}