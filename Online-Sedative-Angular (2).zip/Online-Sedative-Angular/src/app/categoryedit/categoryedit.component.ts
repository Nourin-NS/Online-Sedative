import { Component, OnInit } from '@angular/core';
import { ProductserviceService } from '../productservice.service'; 

import { ActivatedRoute, Router } from '@angular/router'; 
import { Vendor } from '../vendor';
import { Category } from '../category';
@Component({
  selector: 'app-categoryedit',
  templateUrl: './categoryedit.component.html',
  styleUrls: ['./categoryedit.component.css']
})
export class CategoryeditComponent implements OnInit {
  category:Category= new Category() ;   
  id : number=0; 
 
  constructor(private service:ProductserviceService,private activeRouter:ActivatedRoute, private router:Router) { } 
 
  ngOnInit(): void {     this.category =new Category(); 
    this.id=this.activeRouter.snapshot.params['id'];     this.service.getOneCategory(this.id).subscribe(       data=>{ 
        this.category=data; 
      } 
    );   } 	
updateCategory(){ 
  
    this.service.updateCategory(this.category).subscribe(data=>{ 
       console.log(data), this.router.navigate(['\adminlogin/catall']);
    });
     
     
  } 
}