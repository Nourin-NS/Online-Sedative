import { Component, OnInit } from '@angular/core';

import { ProductserviceService } from '../productservice.service'; 
import { Router } from '@angular/router'; 
import { Product } from '../product'; 
import { Message } from '../message';  
import { Discount } from '../discount';
import { Category } from '../category';
import { Vendor } from '../vendor';


@Component({
  selector: 'app-productcreate',
  templateUrl: './productcreate.component.html',
  styleUrls: ['./productcreate.component.css']
})
export class ProductcreateComponent implements OnInit {

  product : Product = new Product();   
  message : Message = new Message(); 
  disc1:Discount[]=[];
  category1:Category[]=[];
  vendor1:Vendor[]=[];
  constructor(private service:ProductserviceService,private router:Router) { }  
  ngOnInit(): void { 
   } 
  createStudent(){ 
    this.service.createStudent(this.product).subscribe(data=>{       this.message=data; 
    }); 
    this.product=new Product(); 
  } 
 
  getAllDiscount(){ 
    this.service.getAllDiscount().subscribe(data=>{this.disc1=data}
,       error=>{this.disc1=[] 
      });   } 

      selected = "----"
  
  update(e:any){
    this.selected = e.target.value
    
  }

  selected1="----"
  getAllCategory(){ 
    this.service.getAllCategory().subscribe(data=>{this.category1=data}
,       error=>{this.category1=[] 
      });   } 

      
  update1(e:any){
    this.selected1 = e.target.value
    
  }

  selected2="----"
  getAllVendor(){ 
    this.service.getAllVendor().subscribe(data=>{this.vendor1=data}
,       error=>{this.vendor1=[] 
      });   } 

      
  update2(e:any){
    this.selected2 = e.target.value
    
  }
} 
