export class Category {

    catid:number=0;
    catname:string="";

}
