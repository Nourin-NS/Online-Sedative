import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Message } from '../message';

import { ProductserviceService } from '../productservice.service';
import { Vendor } from '../vendor';

import * as pdfMake from "pdfmake/build/pdfmake";
import * as pdfFonts from "pdfmake/build/vfs_fonts";
declare var require: any;
const htmlToPdfmake = require("html-to-pdfmake");
(pdfMake as any).vfs = pdfFonts.pdfMake.vfs;

@Component({
  selector: 'app-vendordetails',
  templateUrl: './vendordetails.component.html',
  styleUrls: ['./vendordetails.component.css']
})
export class VendordetailsComponent implements OnInit {

 
  vendor : Vendor[]=[]; 
  message  : Message = new Message(); 
 
  
  @ViewChild('pdfTable')
  pdfTable!: ElementRef;
  
  public downloadAsPDF() {
    const pdfTable = this.pdfTable.nativeElement;
    var html = htmlToPdfmake(pdfTable.innerHTML);
    const documentDefinition = { content: html };
    pdfMake.createPdf(documentDefinition).download('vendor details.pdf'); 
     
  }
  constructor(private service:ProductserviceService, private router:Router) {
 } 
 
  ngOnInit(): void {     this.getAllVendor(); 
  }  



  getAllVendor(){ 
    this.service.getAllVendor().subscribe(data=>{this.vendor=data}
,       error=>{this.vendor=[] 
      });   } 

      
}
