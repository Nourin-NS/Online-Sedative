import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdminComponent } from './admin/admin.component';
import { UserComponent } from './user/user.component';
import { ReportsComponent } from './reports/reports.component';

import { HomeComponent } from './home/home.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import{HttpClientModule} from '@angular/common/http';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { ProductallComponent } from './productall/productall.component';
import { ProductcreateComponent } from './productcreate/productcreate.component';
import { ProducteditComponent } from './productedit/productedit.component';
import { CustomerallComponent } from './customerall/customerall.component';
import { CustomeraddComponent } from './customeradd/customeradd.component';
import { CustomerdeleteComponent } from './customerdelete/customerdelete.component';
import { CreditComponent } from './credit/credit.component';
import { OrderproductComponent } from './orderproduct/orderproduct.component';
import { OrderconfirmComponent } from './orderconfirm/orderconfirm.component';
import { DisplayorderComponent } from './displayorder/displayorder.component';
import { VendorcreateComponent } from './vendorcreate/vendorcreate.component';
import { VendorallComponent } from './vendorall/vendorall.component';
import { VendoreditComponent } from './vendoredit/vendoredit.component';
import { ProductdetailsComponent } from './productdetails/productdetails.component';
import { VendordetailsComponent } from './vendordetails/vendordetails.component';
import { CategoryallComponent } from './categoryall/categoryall.component';
import { CategorycreateComponent } from './categorycreate/categorycreate.component';
import { CategoryeditComponent } from './categoryedit/categoryedit.component';
import { CategorydisplayComponent } from './categorydisplay/categorydisplay.component';
import { DiscountallComponent } from './discountall/discountall.component';
import { DiscountcreateComponent } from './discountcreate/discountcreate.component';
import { DiscounteditComponent } from './discountedit/discountedit.component';
import { DiscountdetailsComponent } from './discountdetails/discountdetails.component';




@NgModule({
  declarations: [
    AppComponent,
    AdminComponent,
    UserComponent,
    ReportsComponent,
    
    HomeComponent,
    AdminloginComponent,
    ProductallComponent,
    ProductcreateComponent,
    ProducteditComponent,
    CustomerallComponent,
    CustomeraddComponent,
    CustomerdeleteComponent,
    CreditComponent,
    OrderproductComponent,
    OrderconfirmComponent,
    DisplayorderComponent,
    VendorcreateComponent,
    VendorallComponent,
    VendoreditComponent,
    ProductdetailsComponent,
    VendordetailsComponent,
    CategoryallComponent,
    CategorycreateComponent,
    CategoryeditComponent,
    CategorydisplayComponent,
    DiscountallComponent,
    DiscountcreateComponent,
    DiscounteditComponent,
    DiscountdetailsComponent,
  
  
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
