export class Customer {
    cid : number=0;     
    cname : string="";       
    cuser: string="";
    cpwd:string="";
}
