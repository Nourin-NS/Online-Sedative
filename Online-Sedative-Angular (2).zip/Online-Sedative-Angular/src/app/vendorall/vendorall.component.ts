import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Message } from '../message';
import { Product } from '../product';
import { ProductserviceService } from '../productservice.service';
import { Vendor } from '../vendor';

@Component({
  selector: 'app-vendorall',
  templateUrl: './vendorall.component.html',
  styleUrls: ['./vendorall.component.css']
})
export class VendorallComponent implements OnInit {

  vendor : Vendor[]=[]; 
  message  : Message = new Message(); 
 
  constructor(private service:ProductserviceService, private router:Router) {
 } 
 
  ngOnInit(): void {     this.getAllVendor(); 
  }  

  deleteVendor(id:number){ 
    this.service.deleteOneVendor(id).subscribe( 
      data=>{         this.message=data,         this.getAllVendor(); 
      }, 
      error=>{console.log(error)} 
      ); 
       } 

  getAllVendor(){ 
    this.service.getAllVendor().subscribe(data=>{this.vendor=data}
,       error=>{this.vendor=[] 
      });   } 

      editVendor(pid:number){ 
        this.router.navigate(['vedit',pid]); 
      } 
    
}
