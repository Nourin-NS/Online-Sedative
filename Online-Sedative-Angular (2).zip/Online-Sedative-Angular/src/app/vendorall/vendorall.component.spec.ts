import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VendorallComponent } from './vendorall.component';

describe('VendorallComponent', () => {
  let component: VendorallComponent;
  let fixture: ComponentFixture<VendorallComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VendorallComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VendorallComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
