export class Message {
    type : string="";    
message: string=""; 

}
